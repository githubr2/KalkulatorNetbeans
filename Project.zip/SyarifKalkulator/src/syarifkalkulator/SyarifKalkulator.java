/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package syarifkalkulator;

/**
 * @author MhdSyarif
 * 03 Januari 2013
 * Tugas I Java2SE
 * D4 TKJMD Batch 8 ITB
 * BLog : www.mhdsyarif.com
 */
public class SyarifKalkulator { //Class main

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new syarifkalkulator.HomeKalkulator().setVisible(true); //Memanggil file HomeKalkulator.java
    }
}
